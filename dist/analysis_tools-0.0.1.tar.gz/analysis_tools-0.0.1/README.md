Simple convenient function created by Roger Ianjamasimanana
